import 'package:flutter/material.dart';
import '../services/prefs_service.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  final _prefs = PrefsService();
  List<String> _favorites = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() async {
    _favorites = await _prefs.loadFavorites();
    setState(() {});
  }

  void _delete(int index) async {
    _favorites.removeAt(index);
    await _prefs.saveFavorites(_favorites);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Favorites')),
      body: _favorites.isEmpty
          ? const Center(child: Text('No favorites yet'))
          : ListView.builder(
              itemCount: _favorites.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(_favorites[index]),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () => _delete(index),
                  ),
                );
              },
            ),
    );
  }
}
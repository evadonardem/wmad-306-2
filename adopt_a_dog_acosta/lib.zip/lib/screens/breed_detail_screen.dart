import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/breed.dart';
import '../services/dog_api_service.dart';
import '../services/prefs_service.dart';

class BreedDetailScreen extends StatefulWidget {
  final Breed breed;

  const BreedDetailScreen({super.key, required this.breed});

  @override
  State<BreedDetailScreen> createState() => _BreedDetailScreenState();
}

class _BreedDetailScreenState extends State<BreedDetailScreen> {
  late Future<String> _imageFuture;
  final _api = DogApiService();
  final _prefs = PrefsService();

  String? _selectedSub;

  @override
  void initState() {
    super.initState();
    _imageFuture = _api.fetchRandomImage(widget.breed.name);
  }

  void _selectSub(String sub) {
    setState(() {
      _selectedSub = sub;
      _imageFuture =
          _api.fetchRandomImage('${widget.breed.name}/$sub');
    });
  }

  void _refresh() {
    setState(() {
      _imageFuture = _api.fetchRandomImage(
        _selectedSub != null
            ? '${widget.breed.name}/$_selectedSub'
            : widget.breed.name,
      );
    });
  }

  Future<void> _saveFavorite() async {
    final list = await _prefs.loadFavorites();

    if (!list.contains(widget.breed.name)) {
      list.add(widget.breed.name);
      await _prefs.saveFavorites(list);
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${widget.breed.name} saved!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.breed.name)),
      body: FutureBuilder<String>(
        future: _imageFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('${snapshot.error}'));
          }

          final url = snapshot.data!;

          return Column(
            children: [
              if (widget.breed.subBreeds.isNotEmpty)
                SizedBox(
                  height: 50,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: widget.breed.subBreeds.map((sub) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: ChoiceChip(
                          label: Text(sub),
                          selected: _selectedSub == sub,
                          onSelected: (_) => _selectSub(sub),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              Expanded(
                child: CachedNetworkImage(
                  imageUrl: url,
                  fit: BoxFit.cover,
                  width: double.infinity,
                  placeholder: (context, url) =>
                      const Center(child: CircularProgressIndicator()),
                  errorWidget: (context, url, error) =>
                      const Icon(Icons.broken_image),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: _refresh,
                    child: const Text('New Photo'),
                  ),
                  ElevatedButton(
                    onPressed: _saveFavorite,
                    child: const Text('Favorite'),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }
}
import 'package:shared_preferences/shared_preferences.dart';

class PrefsService {
  static const _keyFavorites = 'favorite_breeds';
  static const _keySearch = 'search_term';

  // SAVE LIST
  Future<void> saveFavorites(List<String> breeds) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_keyFavorites, breeds);
  }

  // LOAD LIST
  Future<List<String>> loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_keyFavorites) ?? [];
  }

  // SAVE SEARCH
  Future<void> saveSearch(String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keySearch, value);
  }

  // LOAD SEARCH
  Future<String> loadSearch() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keySearch) ?? '';
  }
}